Setuptools has moved!
=====================

Setuptools can now be found at https://github.com/pypa/setuptools.
